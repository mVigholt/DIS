-- Drop the Users table if it exists, along with any dependent objects
DROP TABLE IF EXISTS Users CASCADE;

-- Create the Managers table with the required fields
CREATE TABLE IF NOT EXISTS Managers(
    pk serial NOT NULL PRIMARY KEY,
    full_name VARCHAR(50),
    club VARCHAR(50)
);

-- Create an index on the Managers table
CREATE INDEX IF NOT EXISTS managers_index
ON Managers (pk);

-- Delete all records from the Managers table
DELETE FROM Managers;

-- Insert a sample manager into the Managers table
INSERT INTO Managers(full_name, club)
VALUES ('Sample Manager', 'Sample Club');
